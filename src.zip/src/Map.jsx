import React from 'react';
import Sketch from "react-p5";
import mockPedidos from './mock/pedidos.js';


const Map = (blockSize_p) => {
    const blockSize = blockSize_p.blockSize_p;

    const setup = (p5, canvasParentRef) => {
		p5.createCanvas(blockSize*70, blockSize*50).parent(canvasParentRef);
        
	};

    const renderGrid = (p5) =>{
        p5.stroke(100);
        p5.strokeWeight(6);
        p5.rect(0, 0, p5.width, p5.height);
        for (var i=0; i<p5.width; i=i+blockSize){
            p5.stroke(p5.color(69,69,69));
            p5.strokeWeight(1);
            p5.line(i,0,i,p5.height);
            p5.line(0,i,p5.width,i);
        }
        
    }

    const renderTruck = (p5, route) => {
        var dateNow = Date.now();
        var startDate = new Date(route.startDate);
        //var velocity = 13.888;
        var velocity = 3000;
        
        if (startDate > dateNow) return;

        var transTime = (dateNow - startDate)/1000; //in seconds
        var distance = transTime*velocity;
        var curNode = Math.trunc(distance/1000);
        if (curNode >= route.path.length) return;
        

        var leftDirection = 0;
        var rightDirection = 0;
        var upDirection = 0;
        var downDirection = 0;
        
        //Evaluar la direccion segun el siguiente nodo
        if(curNode < route.path.length-1){            
            if(route.path[curNode]['x'] < route.path[curNode+1]['x']) rightDirection=1; // ->
            if(route.path[curNode]['x'] > route.path[curNode+1]['x']) leftDirection=-1; // <-
            if(route.path[curNode]['y'] < route.path[curNode+1]['y']) downDirection=1; // v
            if(route.path[curNode]['x'] > route.path[curNode+1]['x']) upDirection=-1; // ^ 
        }

        
        p5.ellipse(route.path[curNode]['x']*blockSize + (rightDirection+leftDirection)*(distance - curNode*1000)*0.02, //restar la mitad del camion
        route.path[curNode]['y']*blockSize + (upDirection+downDirection)*(distance - curNode*1000)*0.02,
        25,25);

    }
    

    const draw = (p5) => {
        p5.background(255);
        renderGrid(p5);

        //Renderizar Plantas

        for(var i=0;i<mockPedidos.length;i++){
            renderTruck(p5, mockPedidos[i]);
        }

	};


  return <Sketch setup={setup} draw={draw} />;
}

export default Map;
