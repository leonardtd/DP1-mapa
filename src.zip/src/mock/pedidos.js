export default [
    {
        id: 1,
        startDate: "2021-10-10 18:58:10",
        path: [
            {x:1,y:1}, //A la hora start date, estare aqui
            {x:1,y:2},
            {x:1,y:3},
            {x:1,y:4},
            {x:1,y:5},
            {x:1,y:6},
            {x:1,y:7},
            {x:1,y:8},
            {x:2,y:8}
        ]

    }
];